// 4. Faça um programa que peça 4 números inteiros. Em seguida, apresente quantos números informados 
// são negativos e quantos são positivos (considere o 0 como positivo). Exemplos de execução:
// 	N1: 12		N1: -1
// 	N2: 4			N2: -20
// 	N3: -3		N3: -7
// 	N4: 5			N4: -11
// 	3 (+) e 1 (-)	0 (+) e 4 (-)


#include <stdio.h>
#include <stdlib.h>
int main () {
    int num;
    int numNeg = 0;
    int numPos = 0;
    printf("Digite 4 números inteiros: \n"); 
    for (int i = 0 ; i  < 4; i++ ){
        scanf ("%d",&num);
        if (num >= 0 ){
            numPos++ ;
        } else {
            numNeg++;
        }
    }
    printf ("%d Positivos e %d Negativos ", numPos, numNeg);
    return 0;
}
