// 2. Uma loja vende produtos à vista e a prazo (pagamento 30 dias depois da compra). 
// À vista tem um desconto de 5% e a prazo um acréscimo de 10%. Faça um programa em C 
// que peça o preço do produto e a forma de pagamento: 1 para à vista e 2 para a prazo. 
// Depois apresente o preço final do produto. Exemplos de execução:
// 	Preço do produto: 120.00				Preço do produto: 200.00
// 	Forma de pagamento: 1				Forma de pagamento: 2
// 	Preço a vista: 114.00				Preço a prazo: 220.00


#include <stdio.h>
#include <stdlib.h>
int main ()
{
    int forma;
    float preco, precofinal;
    printf(" Informa o preco do produto: ");
    scanf ("%f", &preco);
    printf(" Informa a forma do pagamento ( 1 para a vista e 2 para a prazo): ");
    scanf ("%d", &forma);
    if (forma == 1){
        precofinal = preco - (preco*0.05);
        printf ("Preco a vista: %.2f\n", precofinal);
    }else {
        if (forma == 2){
            precofinal = preco + (preco *0.10);
            printf ("Preco a prazo: %.2f\n", precofinal);
        }else {
            printf ("Nao tem essa opcao: ");
        }
    }

    return 0;
}
