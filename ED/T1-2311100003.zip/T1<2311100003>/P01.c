// // 1. Faça um programa que peça o número de horas trabalhadas e o valor da hora de um determinado 
// funcionário. Em seguida, calcule o salário do funcionário. Caso o funcionário tenha trabalhado 
// mais de 200 horas, o salário final é acrescido de 5%. Exemplos de execução:
// // 	Horas trabalhadas: 120				Horas trabalhadas: 210
// // 	Valor da hora: 100,00				Valor da hora: 50.00
// // 	Salário: 12000.00					Salário: 11025.00


#include <stdio.h>
#include <stdlib.h>
int main ()
{
    int qHoras, vHora;
    float sal, salario;
    printf ("digite o numero de horas trabalhadas: "); 
    scanf("%d", &qHoras);
    printf ("digite o valor da hora: ");
    scanf ("%d", &vHora);
    if (qHoras > 200){
        sal = (qHoras * vHora);
        salario = (sal + (sal*0.05));
        printf("Salario: %.2f\n", salario);
    }else{
        sal = qHoras * vHora ;
        printf("Salario: %.2f ", sal);
    }
    
    
    return 0;
}
