// 2. Uma loja vende produtos à vista e a prazo (pagamento 30 dias depois da compra). À vista tem um 
// desconto de 5% e a prazo um acréscimo de 10%. Faça um programa em C que peça o preço do produto 
// e a forma de pagamento: 1 para à vista e 2 para a prazo. Depois apresente o preço final do produto. 
// Exemplos de execução:
// 	Preço do produto: 120.00				Preço do produto: 200.00
// 	Forma de pagamento: 1				Forma de pagamento: 2
// 	Preço a vista: 114.00				Preço a prazo: 220.00


#include <stdio.h>
#include <stdlib.h>
int main (){
    int inicio, fim, duracao;
    printf(" Digite a data do inicio : ");
    scanf ("%d", &inicio);
    printf(" Digite a data do fim: ");
    scanf ("%d", &fim);
    if(inicio > fim ){
        duracao = 24 - (inicio - fim);
        printf (" Duracao : %d horas\n", duracao);
    }else {
        duracao = fim - inicio;
        printf ("Duracao : %d horas\n", duracao); 
    }
    return 0;
}
