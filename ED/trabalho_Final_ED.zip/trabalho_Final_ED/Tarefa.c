#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Task {
    int id;
    char description[100];
    int time_limit;
    int completed;
    struct Task* next;
} Task;

//Prototipagem das Funções
void addTask(Task** head, int id, char* description, int time_limit);
void viewTasks(Task* head, int filter);
void markTaskCompleted(Task* head, int id);
void deleteTask(Task** head, int id);
void displayMenu();

// Declaração da função
// assinatura 

Task* sortActiveTasksByTimeLimit(Task* head);  // Declaração da função
Task* sortTasksByID(Task* head);

//Função para Adicionar Tarefas
void addTask(Task** head, int id, char* description, int time_limit) {
    // Verificar se o ID já existe
    Task* temp = *head;
    while (temp != NULL) {
        if (temp->id == id) {
            printf("Erro: ID %d já existe. Por favor, escolha um ID diferente.\n", id);
            return;
        }
        temp = temp->next;
    }

    // Adicionar nova tarefa
    Task* newTask = (Task*)malloc(sizeof(Task));
    newTask->id = id;
    strcpy(newTask->description, description);
    newTask->time_limit = time_limit;
    newTask->completed = 0; // Situação ativa
    newTask->next = NULL;

    if (*head == NULL) {
        *head = newTask;
    } else {
        temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newTask;
    }
}

// Função para ordenar tarefas por ID
Task* sortTasksByID(Task* head) {
    if (head == NULL || head->next == NULL) {
        return head;
    }

    Task* sorted = NULL;
    Task* current = head;
    Task* temp;

    while (current != NULL) {
        temp = current;
        current = current->next;

        if (sorted == NULL || temp->id < sorted->id) {
            temp->next = sorted;
            sorted = temp;
        } else {
            Task* s = sorted;
            while (s->next != NULL && s->next->id < temp->id) {
                s = s->next;
            }
            temp->next = s->next;
            s->next = temp;
        }
    }

    return sorted;
}

//Função para Visualizar Tarefas
void viewTasks(Task* head, int filter) {
    head = sortTasksByID(head);  // Ordenar as tarefas por ID antes de exibir

    Task* temp;
    int completedCount = 0;

    if (filter == 1 || filter == 0) {
        printf("Tarefas Ativas:\n");
        temp = head;
        while (temp != NULL) {
            if (!temp->completed) {
                printf("ID: %d\nDescrição: %s\nTempo Limite: %d horas\nSituação: Ativa\n\n",
                       temp->id, temp->description, temp->time_limit);
            }
            temp = temp->next;
        }
    }

    if (filter == 2 || filter == 0) {
        printf("Tarefas Concluídas:\n");
        temp = head;
        while (temp != NULL) {
            if (temp->completed) {
                printf("ID: %d\nDescrição: %s\nTempo Limite: %d horas\nSituação: Concluída\n\n",
                       temp->id, temp->description, temp->time_limit);
                completedCount++;
            }
            temp = temp->next;
        }
        if (completedCount == 0) {
            printf("Nenhuma tarefa concluída.\n");
        } else {
            printf("Quantidade de tarefas concluídas: %d\n", completedCount);
        }
    }
}


//Função de Ordenação das Tarefas Ativas
Task* sortActiveTasksByTimeLimit(Task* head) {
    Task* sorted = NULL;
    Task* current = head;
    Task* temp;

    // Copiar tarefas ativas para a lista ordenada
    while (current != NULL) {
        if (!current->completed) {
            temp = (Task*)malloc(sizeof(Task));
            *temp = *current;
            temp->next = sorted;
            sorted = temp;
        }
        current = current->next;
    }

    // Ordenar a lista usando o algoritmo de seleção
    Task* i = sorted;
    while (i != NULL) {
        Task* j = i->next;
        while (j != NULL) {
            if (i->time_limit > j->time_limit) {
                // Trocar os dados das tarefas
                int id_temp = i->id;
                char desc_temp[100];
                strcpy(desc_temp, i->description);
                int time_temp = i->time_limit;
                int comp_temp = i->completed;

                i->id = j->id;
                strcpy(i->description, j->description);
                i->time_limit = j->time_limit;
                i->completed = j->completed;

                j->id = id_temp;
                strcpy(j->description, desc_temp);
                j->time_limit = time_temp;
                j->completed = comp_temp;
            }
            j = j->next;
        }
        i = i->next;
    }
    return sorted;
}

// Função para marcar uma tarefa como concluída
void markTaskCompleted(Task* head, int id) {
    Task* temp = head;
    // Percorre a lista até encontrar a tarefa com o ID fornecido
    while (temp != NULL) {
        if (temp->id == id) {
            temp->completed = 1;  // Marca a tarefa como concluída
            printf("Tarefa %d marcada como concluída.\n", id);
            return;
        }
        temp = temp->next;
    }
    // Se a tarefa com o ID fornecido não for encontrada
    printf("Tarefa com ID %d não encontrada.\n", id);
}

// Função para excluir uma tarefa da lista
void deleteTask(Task** head, int id) {
    Task* temp = *head;
    Task* prev = NULL;

    // Se a tarefa a ser excluída é a primeira da lista
    if (temp != NULL && temp->id == id) {
        *head = temp->next;  // Muda a cabeça da lista
        free(temp);  // Libera a memória da tarefa excluída
        printf("Tarefa %d excluída.\n", id);
        return;
    }

    // Percorre a lista para encontrar a tarefa a ser excluída
    while (temp != NULL && temp->id != id) {
        prev = temp;
        temp = temp->next;
    }

    // Se a tarefa com o ID fornecido não for encontrada
    if (temp == NULL) {
        printf("Tarefa com ID %d não encontrada.\n", id);
        return;
    }

    // Remove a tarefa da lista encadeada
    prev->next = temp->next;
    free(temp);  // Libera a memória da tarefa excluída
    printf("Tarefa %d excluída.\n", id);
}

// Função para exibir o menu de opções
void displayMenu() {
    printf("\nMenu de Opções:\n");
    printf("1. Adicionar tarefa\n");
    printf("2. Visualizar todas as tarefas\n");
    printf("3. Visualizar tarefas ativas\n");
    printf("4. Visualizar tarefas concluídas\n");
    printf("5. Marcar tarefa como concluída\n");
    printf("6. Excluir tarefa\n");
    printf("0. Sair\n");
    printf("Escolha uma opção: ");
}


// Função Principal 
int main() {
    Task* head = NULL;
    int option, id, time_limit;
    char description[100];

    do {
        displayMenu();
        scanf("%d", &option);
        switch (option) {
            case 1:
                printf("Digite o ID da tarefa: ");
                scanf("%d", &id);
                printf("Digite a descrição da tarefa: ");
                scanf(" %[^\n]%*c", description);
                printf("Digite o tempo limite (em horas): ");
                scanf("%d", &time_limit);
                addTask(&head, id, description, time_limit);
                break;
            case 2:
                printf("Todas as tarefas (ordenadas):\n");
                viewTasks(head, 0);
                break;
            case 3:
                printf("Tarefas ativas (ordenadas):\n");
                viewTasks(head, 1);
                break;
            case 4:
                printf("Tarefas concluídas:\n");
                viewTasks(head, 2);
                break;
            case 5:
                printf("Digite o ID da tarefa a ser marcada como concluída: ");
                scanf("%d", &id);
                markTaskCompleted(head, id);
                break;
            case 6:
                printf("Digite o ID da tarefa a ser excluída: ");
                scanf("%d", &id);
                deleteTask(&head, id);
                break;
            case 0:
                printf("Saindo...\n");
                break;
            default:
                printf("Opção inválida!\n");
                break;
        }
    } while (option != 0);

    return 0;
}
