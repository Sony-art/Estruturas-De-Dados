#include <stdio.h>
int main ()
{
    char op;
    float n1,n2,res;
    printf("Digite a operacao desejada:\n");
    scanf("%c",&op);
    printf("Digite dois numeros inteiros: ");
    scanf("%f",&n1);
    scanf("%f",&n2);
    if (op=='+')
    {
        res = n1+n2;
        printf ("Resultado: %f ", res);
    }
    else {
        if (op=='*'){
            res = n1 * n2;
            printf("Resultado: %f ",res);
        }
        else{
            if (op == '-'){
                res = n1-n2;
                printf("Resultado: %f ", res);
            }else{
                res = n1/n2;
                printf("Resultado: %.2f ",res);
            }
        }

    }
    return 0;
}