#include <stdio.h>
int main ()
{
    int num,fat = 1;
    printf ("Digite um numero pra ver o fatorial: ");
    scanf("%d", &num);
    for (int i=2; i<=num; i++)
    {
        fat *= i;
    }
    printf("o fatorial eh: %d ",fat);
    return 0;
}