#include <stdio.h>
int main ()
{
    int valor, res = 0 ;
    printf("informe um valor inteiro: ");
    scanf("%d",&valor);
    for (int i=1; i<=valor; i++ )
    {
        res += i;
    
    }
    printf("Resultado: %d ", res);
   return 0;
}