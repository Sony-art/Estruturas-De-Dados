#include <stdio.h>
int main ()
{
    int n1, n2, res = 0;
    printf ("Digite 1 numeros inteiro para fazer a soma: ");
    scanf ("%d",&n1);
    printf("Digite o numero de vezes que o primeiro deve somar: ");
    scanf("%d", &n2);

    for (int i=0; i<n2; i++)
    {
        res+=n1 ;
    }
    printf("Resultado: %d\n", res);
    return 0;
}