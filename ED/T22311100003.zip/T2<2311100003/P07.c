#include <stdio.h>
int main()
{
    int salario, numdefilhos, totalsal= 0, totalfilhos= 0, pop=0;
    while(1){
        printf("Digite salario de um habitante (digite um numero negativo pra finalizar): ");
        scanf("%d",&salario);
        
        if (salario < 0)
        {
            break;
        }
        printf("Informe o numero de filhos: ");
        scanf("%d",&numdefilhos);
        
        if (numdefilhos>=0) {
            totalfilhos+=numdefilhos;
            totalsal+=salario;
            pop++;
        }
        
    }
    if (pop > 0){
        float media = ((float)totalsal/pop);
        printf ("Media salario: %.1f ", media);
        float Media = ((float)totalfilhos/pop);
        printf("Mediafilhos: %.1f ",Media);
        }else {
        printf("nao foi digitado nenhum numero ");
    }
     return 0;
}