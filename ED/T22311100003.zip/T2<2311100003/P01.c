#include <stdio.h>

int main() {
    int numero;
printf("Digite um número maior que 1: ");
    scanf("%d", &numero);
      if (numero <= 1) {
        printf("Por favor, digite um número maior que 1.\n");
    } else {
        for (int i = 1; i <= numero; i++) {
            printf("%d\n", i);
            if (i==(numero / 2) ) {
                printf("Metade\n");
            }
        }
    }

    return 0;
}