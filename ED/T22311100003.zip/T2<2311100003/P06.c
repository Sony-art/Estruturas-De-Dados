#include <stdio.h>

int main() {
    int numero;
    int totalNumeros = 0;
    int numerosEntre10e20 = 0;

    while (1) {
        printf("Informe um número (digite 0 para finalizar): ");
        scanf("%d", &numero);

        if (numero == 0) {
            break; 
        }

        totalNumeros++; 

        if (numero >= 10 && numero <= 20) {
            numerosEntre10e20++; 
        }
    }

    if (totalNumeros > 0) {
        float porcentagem = ((float)numerosEntre10e20 / totalNumeros) * 100;
        printf("%% entre 10 e 20: %.2f%%\n", porcentagem);
    } else {
        printf("Nenhum número foi inserido.\n");
    }

    return 0;
}
