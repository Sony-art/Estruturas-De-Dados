#include <stdio.h>
#include <string.h>

int main() {
    char times[4] = {'A', 'B', 'C', 'D'};
    int pontos[4] = {0, 0, 0, 0};
    char nomeTime;
    int golsTime;

    while (1) {
        printf("Time: ");
        scanf(" %c", &nomeTime);

        if (nomeTime != 'A' && nomeTime != 'B' && nomeTime != 'C' && nomeTime != 'D') {
            break;
        }

        printf("Gols: ");
        scanf("%d", &golsTime);
        
        int indice = -1;
        for (int i = 0; i < 4; i++) {
            if (times[i] == nomeTime) {
                indice = i;
                break;
            }
        }

        if (indice != -1) {
            if (golsTime > 0) {
                pontos[indice] += 3; 
            } else if (golsTime == 0) {
                pontos[indice] += 1; 
            }
        }
    }

   
    char campeao = ' ';
    int maxPontos = 0;
    for (int i = 0; i < 4; i++) {
        if (pontos[i] > maxPontos) {
            campeao = times[i];
            maxPontos = pontos[i];
        } else if (pontos[i] == maxPontos) {
            campeao = ' '; 
        }
    }

    // Exibir os resultados.
    for (int i = 0; i < 4; i++) {
        printf("%c: %d pontos\n", times[i], pontos[i]);
    }

    if (campeao != ' ') {
        printf("Campeão: %c\n", campeao);
    } else {
        printf("Não houve campeão.\n");
    }

    return 0;
}
