#include <stdio.h>

int main() {
    int matricula;
    float nota, somaNotas = 0;
    int contadorNotas = 0;
    float mediaTurma = 0;

    while (1) {
        printf("Matrícula: ");
        scanf("%d", &matricula);

        if (matricula == 0) {
            break;
        }

        somaNotas = 0;
        contadorNotas = 0;

        printf("Notas (digite 0 para encerrar):\n");
        while (1) {
            printf("Nota %d: ", contadorNotas + 1);
            scanf("%f", &nota);

            if (nota == 0) {
                break;
            }

            somaNotas += nota;
            contadorNotas++;
        }

        if (contadorNotas == 0) {
            printf("O aluno não possui notas registradas.\n");
        } else {
            float mediaAluno = somaNotas / contadorNotas;
            printf("%d, média: %.1f\n", matricula, mediaAluno);
            mediaTurma += somaNotas;
        }
    }

    if (mediaTurma != 0) {
        mediaTurma =mediaTurma/ 10; 
        printf("Média geral da turma: %.1f\n", mediaTurma);
    } else {
        printf("Nenhuma média registrada.\n");
    }

    return 0;
}
